module.exports = {
  content: ["./**/*.php"],
  theme: {},
  plugins: [],
}