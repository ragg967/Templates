<?php
echo '<div class="bg-blue-500 text-white p-4 rounded">HTMX and Tailwind are working!</div>';
?>2