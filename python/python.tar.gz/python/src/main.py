#!/usr/bin/env python3
"""
Main module for the application.
"""

def main():
	print("Hi")

if __name__ == "__main__":
	main()