#include <iostream>

int main() {
    std::cout << "Hi\n";
}
